const data = [
  {
    "id": "1", 
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-loft.jpg",
    "link": "https://www.gedimat.fr/article-salle-de-bains-loft-contemporain-un-style-au-caractere-bien-trempe-2316.htm"
  },
  {
    "id": "2",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-retro.jpg",
    "link": "https://www.gedimat.fr/article-salle-de-bains-retro-cool-une-ambiance-deliberement-originale-2318.htm"
  },
  {
    "id": "3",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-scandi.jpg",
    "link": "https://www.gedimat.fr/article-salle-de-bains-scandi-boheme-un-mariage-harmonieux-des-tons-sable-et-terracotta-2364.htm"
  },
  {
    "id": "4",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-classique-chic-2023.jpg",
    "link": "https://www.gedimat.fr/article-sdb-classique-chic-campagne-chic-2446.htm"
  },
  {
    "id": "5",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-retro-cool-2022-1.jpg",
    "link": "https://www.gedimat.fr/article-sdb-retro-cool-haute-en-couleur-2449.htm"
  },
  {
    "id": "6",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-retro-cool-2022.jpg",
    "link": "https://www.gedimat.fr/article-sdb-retro-cool-vue-mer-dans-grenier-2452.htm"
  },
  {
    "id": "7",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-noir.jpg",
    "link": "https://www.gedimat.fr/article-salle-de-bains-noir-et-blanc-un-espace-audacieux-chic-et-indemodable-2317.htm"
  },
  {
    "id": "8",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-design.jpg",
    "link": "https://www.gedimat.fr/article-salle-de-bains-design-epure-epuree-et-audacieuse-2362.htm"
  },
  {
    "id": "9",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-noir-et-blanc-2023.jpg",
    "link": "https://www.gedimat.fr/article-salle-de-bains-noir-et-blanc-chic-et-elegante-effet-damier-2480.htm"
  },
  {
    "id": "10",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-retro-cool-2023.jpg",
    "link": "https://www.gedimat.fr/article-sdb-retro-cool-style-assume-2447.htm"
  },
  {
    "id": "11",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-noir-et-blanc-2022.jpg",
    "link": "https://www.gedimat.fr/article-sdb-noir-et-blanc-contraste-moderne-et-elegante-2450.htm"
  },
  {
    "id": "12",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-evasion-exotique-2024.jpg",
    "link": "https://www.gedimat.fr/article-sdb-evasion-exotique-a-l-heure-des-tropiques-2443.htm"
  },
  {
    "id": "13",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-classique.jpg",
    "link": "https://www.gedimat.fr/article-salle-de-bains-classique-chic-romantique-et-intemporelle-2315.htm"
  },
  {
    "id": "14",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-noir2.jpg",
    "link": "https://www.gedimat.fr/article-salle-de-bains-noir-et-blanc-graphique-et-elegante-2363.htm"
  },
  {
    "id": "15",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-loft-indus-2023.jpg",
    "link": "https://www.gedimat.fr/article-sdb-loft-contemporain-style-urbain-affirme-2445.htm"
  },
  {
    "id": "16",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-evastion-exotique-2022.jpg",
    "link": "https://www.gedimat.fr/article-sdb-evasion-exotique-evasion-matinale-douche-tropicale-2448.htm"
  },
  {
    "id": "17",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-scandi-boheme-2022.jpg",
    "link": "https://www.gedimat.fr/article-sdb-scandi-boheme-ambiance-sauna-apaisant-2451.htm"
  },
  {
    "id": "18",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-noir-et-blanc-duel-2025.jpg",
    "link": "https://www.gedimat.fr/article-salle-de-bains-noir-blanc-2520.htm"
  },
  {
    "id": "19",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-design-epure-duel-2025.jpg",
    "link": "https://www.gedimat.fr/article-salle-de-bains-design-epure-2521.htm"
  },
  {
    "id": "20",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-loft-contemporain-2025.jpg",
    "link": "https://www.gedimat.fr/article-salle-de-bains-loft-contemporain-2495.htm"
  },
  {
    "id": "21",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-evasion-exotique-2025.jpg",
    "link": "https://www.gedimat.fr/article-salle-de-bains-evasion-exotique-2499.htm"
  },
  {
    "id": "22",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-classique-chic-2025.jpg",
    "link": "https://www.gedimat.fr/article-salle-de-bains-classique-chic-2503.htm"
  },
  {
    "id": "23",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-retro-cool-2025.jpg",
    "link": "https://www.gedimat.fr/article-salle-de-bains-retro-cool-2509.htm"
  }
];
