const data = [
  {
    "id": "1",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/galerie/entree/3.jpg",
    "link": "/article-entree-classique-chic-le-papier-peint-vous-transporte-entre-passe-et-present-2358.htm"
  },
  {
    "id": "2",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/cuisine/cuisine-classique-40.jpg",
    "link": "/article-cuisine-classique-chic-un-choix-ose-pour-lespace-cuisine-2348.htm"
  },
  {
    "id": "3",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/exterieur/terrasse-classique-2359.jpg",
    "link": "/article-terrasse-classique-chic-une-terrasse-entre-modernite-et-sobriete-2359.htm"
  },
  {
    "id": "4",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-classique.jpg",
    "link": "/article-salle-de-bains-classique-chic-romantique-et-intemporelle-2315.htm"
  },
  {
    "id": "5",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sejour/sejour-classique-chic-2023.jpg",
    "link": "/article-sejour-classique-chic-une-piece-de-vie-intemporelle-2418.htm"
  },
  {
    "id": "6",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sejour/sejour-classique-chic-2022.jpg",
    "link": "/article-sejour-classique-chic-un-pigeonnier-authentique-2422.htm"
  },
  {
    "id": "7",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/cuisine/cuisine-classique-chic-2023.jpg",
    "link": "/article-cuisine-classique-chic-2023-ouverte-et-raffinee-2428.htm"
  },
  {
    "id": "8",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/chambre/chambre-classique-chic-2022.jpg",
    "link": "/article-chambre-classique-chic-teletravail-chambre-parental-2437.htm"
  },
  {
    "id": "9",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-classique-chic-2023.jpg",
    "link": "/article-sdb-classique-chic-campagne-chic-2446.htm"
  },
  {
    "id": "10",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/exterieur/exterieur-classique-chic-2023-2453.jpg",
    "link": "/article-exterieur-classique-chic-sur-la-cote-fleurie-2453.htm"
  },
  {
    "id": "11",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/exterieur/exterieur-classique-chic-2023-2456.jpg",
    "link": "/article-exterieur-classique-chic-maison-de-caractere-2456.htm"
  },
  {
    "id": "12",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/exterieur/exterieur-classique-chic-2022-2458.jpg",
    "link": "/article-exterieur-classique-chic-esprit-guinguette-chic-2458.htm"
  },
  {
    "id": "13",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/exterieur/exterieur-classique-chic-2022-2464.jpg",
    "link": "/article-exterieur-classique-chic-terrasse-et-piscine-2464.htm"
  },
  {
    "id": "14",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-classique-chic-2025.jpg",
    "link": "/article-salle-de-bains-classique-chic-2503.htm"
  },
  {
    "id": "15",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sejour/sejour-classique-chic-2025.jpg",
    "link": "/article-sejour-classique-chic-2504.htm"
  },
  {
    "id": "16",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/chambre/chambre-classique-chic-2025.jpg",
    "link": "/article-chambre-classique-chic-2505.htm"
  },
  {
    "id": "17",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/entree/entree-classique-chic-duel-2025.jpg",
    "link": "/article-entree-classique-chic-2515.htm"
  }
];
