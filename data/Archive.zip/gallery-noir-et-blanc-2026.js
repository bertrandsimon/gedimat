const data = [
  {
    "id": "1",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/noir-salon.jpg",
    "link": "/article-sejour-noir-et-blanc-un-salon-style-pour-un-espace-de-caractere-2354.htm"
  },
  {
    "id": "2",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/noir-sdb2.jpg",
    "link": "/article-salle-de-bains-noir-et-blanc-graphique-et-elegante-2363.htm"
  },
  {
    "id": "3",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/exterieur-noir-et-blanc-2022.jpg",
    "link": "/article-exterieur-noir-et-blanc-intemportel-aux-contrastes-marques-2469.htm"
  },
  {
    "id": "4",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/noir-sdb1.jpg",
    "link": "/article-salle-de-bains-noir-et-blanc-un-espace-audacieux-chic-et-indemodable-2317.htm"
  },
  {
    "id": "5",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/noir-terrasse.jpg",
    "link": "/article-terrasse-noir-et-blanc-une-terrasse-chic-et-confortable-2314.htm"
  },
  {
    "id": "6",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/sdb-noir-et-blanc-2023.jpg",
    "link": "/article-salle-de-bains-noir-et-blanc-chic-et-elegante-effet-damier-2480.htm"
  },
  {
    "id": "7",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/noir-cuisine.jpg",
    "link": "/article-cuisine-noir-et-blanc-ambiance-chic-et-sobre-pour-le-coin-repas-2349.htm"
  },
  {
    "id": "8",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/sdb-noir-et-blanc-2022.jpg",
    "link": "/article-sdb-noir-et-blanc-contraste-moderne-et-elegante-2450.htm"
  },
  {
    "id": "9",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/chambre/chambre-noir-et-blanc-2025.jpg",
    "link": "/article-chambre-noir-blanc-2491.htm"
  },
  {
    "id": "10",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/exterieur/exterieur-noir-et-blanc-2025.jpg",
    "link": "/article-exterieur-noir-blanc-2492.htm"
  },
  {
    "id": "11",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/entree/entree-noir-et-blanc-2025.jpg",
    "link": "/article-entree-noir-blanc-2493.htm"
  },
  {
    "id": "12",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/cuisine/cuisine-noir-et-blanc-duel-2025.jpg",
    "link": "/article-cuisine-noir-blanc-2517.htm"
  },
  {
    "id": "13",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-noir-et-blanc-duel-2025.jpg",
    "link": "/article-salle-de-bains-noir-blanc-2520.htm"
  }
];
