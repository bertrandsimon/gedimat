const data = [
  {
    "id": "1", 
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/entree/entree-evasion-exotique-2357.jpg",
    "link": "/article-entree-evasion-exotique-la-nature-nous-inspire-des-lentree-2357.htm"
  },
  {
    "id": "2",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/entree/entree-retro-cool-2356.jpg",
    "link": "/article-entree-retro-cool-une-entree-originale-qui-reveille-limagination-2356.htm"
  },
  {
    "id": "3",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/entree/entree-classique-chic-2358.jpg",
    "link": "/article-entree-classique-chic-le-papier-peint-vous-transporte-entre-passe-et-present-2358.htm"
  },
  {
    "id": "4",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/entree/entree-retro-cool-duel-2025.jpg",
    "link": "/article-entree-retro-cool-2514.htm"
  },
  {
    "id": "5",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/entree/entree-classique-chic-duel-2025.jpg",
    "link": "/article-entree-classique-chic-2515.htm"
  },
  {
    "id": "6",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/entree/entree-noir-et-blanc-2025.jpg",
    "link": "/article-entree-noir-blanc-2493.htm"
  },
  {
    "id": "7",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/entree/entree-loft-contemporain-2025.jpg",
    "link": "/article-entree-loft-contemporain-2494.htm"
  },
  {
    "id": "8",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/entree/entree-scandi-boheme-2025.jpg",
    "link": "/article-entree-scandi-boheme-2502.htm"
  },
  {
    "id": "9",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/entree/entree-design-epure-2025.jpg",
    "link": "/article-entree-design-epure-2507.htm"
  }
  
];
