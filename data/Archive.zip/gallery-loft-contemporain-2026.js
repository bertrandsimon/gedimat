const data = [
    {
      "id" : "1",
      "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/loft-cuisine.jpg",
      "link": "/article-salle-de-bains-loft-contemporain-un-style-au-caractere-bien-trempe-2316.htm"
    },
    {
      "id" : "2",
      "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/loft-sdb.jpg",
      "link": "/article-salle-de-bains-loft-contemporain-un-style-au-caractere-bien-trempe-2316.htm"
    },
    {
        "id" : "3",
        "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/cuisine-loft-indus-2022.jpg",
        "link": "/article-cuisine-loft-contemporain-2022-esprit-bar-pour-recevoir-famille-et-amis-2431.htm"
      },
      {
        "id" : "4",
        "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/chambre-loft-indus-2021.jpg",
        "link": "/article-chambre-loft-contemporain-pour-ado-dans-les-combles-2442.htm"
      },
      {
        "id" : "5",
        "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/exterieur-loft-indus-2021.jpg",
        "link": "/article-exterieur-loft-contemporain-patio-urbain-2467.htm"
      },
      {
        "id" : "6",
        "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/loft-chambre.jpg",
        "link": "/article-chambre-loft-contemporain-melange-brut-delements-contemporains-2347.htm"
      },
      {
        "id" : "7",
        "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/sejour-loft-industriel-2023.jpg",
        "link": "/article-sejour-loft-contemporain-sejour-esprit-factory-2420.htm"
      },
     {
        "id" : "8",
        "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/cuisine-loft-indus-2021.jpg",
        "link": "/article-cuisine-loft-contemporain-2021-moderne-et-style-de-caractere-2432.htm"
      },
      {
        "id" : "9",
        "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/sdb-loft-indus-2023.jpg",
        "link": "/article-sdb-loft-contemporain-style-urbain-affirme-2445.htm"
      },
      {
        "id" : "10",
        "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/loft-terrasse.jpg",
        "link": "/article-terrasse-loft-contemporain-une-terrasse-qui-a-du-caractere-2360.htm"
      },
      {
        "id" : "11",
        "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/sejour-loft-industriel-2021.jpg",
        "link": "/article-sejour-loft-contemporain-hangar-amenage-en-loft-2425.htm"
      },
      {
        "id" : "12",
        "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/chambre-loft-indus-2022.jpg",
        "link": "/article-chambre-loft-contemporain-allures-new-yorkaise-2438.htm"
      },
      {
        "id" : "13",
        "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/exterieur-loft-indus-2.jpg",
        "link": "/article-exterieur-loft-contemporain-deliberement-industriel-2462.htm"
      },
      {
        "id" : "14",
        "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/entree/entree-loft-contemporain-2025.jpg",
        "link": "/article-entree-loft-contemporain-2494.htm"
      },
      {
        "id" : "15",
        "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-loft-contemporain-2025.jpg",
        "link": "/article-salle-de-bains-loft-contemporain-2495.htm"
      },
      {
        "id" : "16",
        "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sejour/sejour-loft-contemporain-2025.jpg",
        "link": "/article-sejour-loft-contemporain-2496.htm"
      },
      {
        "id" : "17",
        "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/exterieur/exterieur-loft-contemporain-duel-2025.jpg",
        "link": "/article-terrasse-loft-contemporain-2513.htm"
      }

]