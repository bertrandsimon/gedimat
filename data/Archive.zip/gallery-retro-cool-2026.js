const data = [
  {
    "id": "1",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/retro-entree.jpg",
    "link": "/article-entree-retro-cool-une-entree-originale-qui-reveille-limagination-2356.htm"
  },
  {
    "id": "2",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/retro-terrasse.jpg",
    "link": "/article-terrasse-retro-cool-un-espace-vintage-qui-swingue-2312.htm"
  },
  {
    "id": "3",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/cuisine-retro-cool-2023.jpg",
    "link": "/article-cuisine-retro-cool-2023-piece-de-vie-pop-et-coloree-2430.htm"
  },
  {
    "id": "4",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/chambre-retro-cool-2022.jpg",
    "link": "/article-chambre-retro-cool-style-et-petit-budget-2439.htm"
  },
  {
    "id": "5",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/sdb-retro-cool-2022.jpg",
    "link": "/article-sdb-retro-cool-vue-mer-dans-grenier-2452.htm"
  },
  {
    "id": "6",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/retro-salon.jpg",
    "link": "https://www.gedimat.fr/article-sejour-retro-cool-mariage-ose-des-formes-et-des-motifs-2353.htm"
  },
  {
    "id": "7",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/retro-sdb.jpg",
    "link": "/article-salle-de-bains-retro-cool-une-ambiance-deliberement-originale-2318.htm"
  },
  {
    "id": "8",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/chambre-retro-cool-2023.jpg",
    "link": "/article-chambre-retro-cool-evolutive-au-charme-immuable-2434.htm"
  },
  {
    "id": "9",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/sdb-retro-cool-2023.jpg",
    "link": "/article-sdb-retro-cool-style-assume-2447.htm"
  },
  {
    "id": "10",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/exterieur-retro-cool-2022.jpg",
    "link": "/article-exterieur-retro-cool-cuisine-d-ete-2463.htm"
  },
  {
    "id": "11",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/retro-chambre.jpg",
    "link": "/article-chambre-retro-cool-vitaminee-et-decomplexee-2346.htm"
  },
  {
    "id": "12",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/sejour-scandi-retro-cool-2022.jpg",
    "link": "/article-sejour-retro-cool-cocon-vintage-annee-70-2424.htm"
  },
  {
    "id": "13",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/sdb-retro-cool-2022-1.jpg",
    "link": "/article-sdb-retro-cool-haute-en-couleur-2449.htm"
  },
  {
    "id": "14",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-retro-cool-2025.jpg",
    "link": "/article-salle-de-bains-retro-cool-2509.htm"
  },
  {
    "id": "15",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/exterieur/exterieur-retro-cool-2025.jpg",
    "link": "/article-exterieur-retro-cool-2510.htm"
  },
  {
    "id": "16",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/cuisine/cuisine-retro-cool-2025.jpg",
    "link": "/article-cuisine-retro-cool-2511.htm"
  },
  {
    "id": "17",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/entree/entree-retro-cool-duel-2025.jpg",
    "link": "/article-entree-retro-cool-2514.htm"
  },
  {
    "id": "18",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/chambre/chambre-retro-cool-duel-2025.jpg",
    "link": "/article-chambre-retro-cool-2518.htm"
  }
];
