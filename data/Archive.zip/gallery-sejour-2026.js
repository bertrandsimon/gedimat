const data = [
  {
    "id": "1", 
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sejour/sejour-scandi-boheme-9.jpg",
    "link": "https://www.gedimat.fr/article-sejour-scandi-boheme-un-salon-lumineux-et-decontracte-aux-accents-dibiza-2355.htm"
  },
  {
    "id": "2",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sejour/sejour-classique-chic-2023.jpg",
    "link": "https://www.gedimat.fr/article-sejour-classique-chic-une-piece-de-vie-intemporelle-2418.htm"
  },
  {
    "id": "3",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sejour/sejour-loft-industriel-2023.jpg",
    "link": "https://www.gedimat.fr/article-sejour-loft-contemporain-sejour-esprit-factory-2420.htm"
  },
  {
    "id": "4",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sejour/sejour-scandi-boheme-2022.jpg",
    "link": "https://www.gedimat.fr/article-sejour-scandi-boheme-accueillant-et-chaleureux-2423.htm"
  },
  {
    "id": "5",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sejour/sejour-loft-scandi-boheme-2021.jpg",
    "link": "https://www.gedimat.fr/article-sejour-scandi-boheme-cosy-et-chaleureux-sous-les-combles-2426.htm"
  },
  {
    "id": "6",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sejour/sejour-retro-cool-22.jpg",
    "link": "https://www.gedimat.fr/article-sejour-noir-et-blanc-un-salon-style-pour-un-espace-de-caractere-2354.htm"
  },
  {
    "id": "7",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sejour/sejour-design-epure-4.jpg",
    "link": "https://www.gedimat.fr/article-sejour-design-epure-la-simplicite-cache-bien-son-jeu-2352.htm"
  },
  {
    "id": "8",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sejour/sejour-evasion-exotique-2023.jpg",
    "link": "https://www.gedimat.fr/article-sejour-evasion-exotique-invitez-la-nature-chez-vous-2421.htm"
  },
  {
    "id": "9",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sejour/sejour-scandi-retro-cool-2022.jpg",
    "link": "https://www.gedimat.fr/article-sejour-retro-cool-cocon-vintage-annee-70-2424.htm"
  },
  {
    "id": "10",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sejour/sejour-design-epure-2021.jpg",
    "link": "https://www.gedimat.fr/article-sejour-design-epure-design-authentique-avec-parement-2427.htm"
  },
  {
    "id": "11",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sejour/sejour-retro-cool3.jpg",
    "link": "https://www.gedimat.fr/article-sejour-retro-cool-mariage-ose-des-formes-et-des-motifs-2353.htm"
   
  },
  {
    "id": "12",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sejour/sejour-design-epure-2023.jpg",
    "link": "https://www.gedimat.fr/article-sejour-design-epure-un-interieur-clair-et-contemporain-2419.htm"
  },
  {
    "id": "13",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sejour/sejour-classique-chic-2022.jpg",
    "link": "https://www.gedimat.fr/article-sejour-classique-chic-un-pigeonnier-authentique-2422.htm"
  },
  {
    "id": "14",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sejour/sejour-loft-industriel-2021.jpg",
    "link": "https://www.gedimat.fr/article-sejour-loft-contemporain-hangar-amenage-en-loft-2425.htm"
  },
  {
    "id": "15",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sejour/sejour-loft-contemporain-2025.jpg",
    "link": "https://www.gedimat.fr/article-sejour-loft-contemporain-2496.htm"
  },
  {
    "id": "16",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sejour/sejour-evasion-exotique-2025.jpg",
    "link": "https://www.gedimat.fr/article-sejour-evasion-exotique-2497.htm"
  },
  {
    "id": "17",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sejour/sejour-classique-chic-2025.jpg",
    "link": "https://www.gedimat.fr/article-sejour-classique-chic-2504.htm"
  }
];
