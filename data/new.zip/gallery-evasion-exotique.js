const data = [
    {
      "id" : "1",
      "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/evasion-entree.jpg",
      "link": "/article-entree-evasion-exotique-la-nature-nous-inspire-des-lentree-2357.htm"
    },
    {
      "id" : "2",
      "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/sdb-evastion-exotique-2022.jpg",
      "link": "/article-sdb-evasion-exotique-evasion-matinale-douche-tropicale-2448.htm"
    },
    {
        "id" : "3",
        "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/sejour-evasion-exotique-2023.jpg",
        "link": "/article-sejour-evasion-exotique-invitez-la-nature-chez-vous-2421.htm"
      },
      {
        "id" : "4",
        "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/evasion-chambre.jpg",
        "link": "/article-chambre-evasion-exotique-mix-match-exotique-2344.htm"
      },
      {
        "id" : "5",
        "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/cuisine-evasion-exotique-2023.jpg",
        "link": "/article-cuisine-evasion-exotique-2023-voyager-tout-au-long-de-l-annee-2429.htm"
      },
      {
        "id" : "6",
        "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/exterieur-evasion-exotique-2022.jpg",
        "link": "/article-exterieur-evasion-exotique-terrasse-decaissee-originale-2459.htm"
      },
      {
        "id" : "7",
        "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/evasion-terrasse.jpg",
        "link": "/article-terrasse-evasion-exotique-une-terrasse-vegetale-et-cosy-pour-un-depaysement-garanti-2361.htm"
      },
     {
        "id" : "8",
        "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/sdb-evasion-exotique-2024.jpg",
        "link": "/article-sdb-evasion-exotique-a-l-heure-des-tropiques-2443.htm"
      },
      {
        "id" : "9",
        "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/cuisine/cuisine-evasion-exotique-2025.jpg",
        "link": "/article-cuisine-evasion-exotique-2498.htm"
      },
      {
        "id" : "10",
        "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sdb/sdb-evasion-exotique-2025.jpg",
        "link": "/article-salle-de-bains-evasion-exotique-2499.htm"
      },
      {
        "id" : "10",
        "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/sejour/sejour-evasion-exotique-2025.jpg",
        "link": "/article-sejour-evasion-exotique-2497.htm"
      }
]