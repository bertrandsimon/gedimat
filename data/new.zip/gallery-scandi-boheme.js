const data = [
  {
    "id": "1",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/scandi-salon.jpg",
    "link": "/article-sejour-scandi-boheme-un-salon-lumineux-et-decontracte-aux-accents-dibiza-2355.htm"
  },
  {
    "id": "2",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/scandi-terrasse.jpg",
    "link": "/article-terrasse-scandinave-boheme-l-esprit-ibiza-chez-soi-2319.htm"
  },
  {
    "id": "3",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/cuisine-scandi-boheme-2021.jpg",
    "link": "/article-cuisine-scandi-boheme-2021-ouverture-sur-la-nature-2433.htm"
  },
  {
    "id": "4",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/chambre-scandi-boheme-2021.jpg",
    "link": "/article-chambre-scandi-boheme-etage-en-chambre-d-ami-2441.htm"
  },
  {
    "id": "5",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/exterieur-scandi-boheme-2023.jpg",
    "link": "/article-exterieur-scandi-boheme-nordique-cocooning-2454.htm"
  },
  {
    "id": "6",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/scandi-cuisine.jpg",
    "link": "/article-cuisine-scandi-boheme-intemporelle-et-depaysante-2350.htm"
  },
  {
    "id": "7",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/sejour-scandi-boheme-2022.jpg",
    "link": "/article-sejour-scandi-boheme-accueillant-et-chaleureux-2423.htm"
  },
  {
    "id": "8",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/chambre-scandi-boheme-2023.jpg",
    "link": "/article-chambre-scandi-boheme-esprit-tiny-house-2435.htm"
  },
  {
    "id": "9",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/sdb-scandi.jpg",
    "link": "/article-salle-de-bains-scandi-boheme-un-mariage-harmonieux-des-tons-sable-et-terracotta-2364.htm"
  },
  {
    "id": "10",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/exterieur-scandi-boheme-2022.jpg",
    "link": "/article-exterieur-scandi-boheme-espace-nordique-2465.htm"
  },
  {
    "id": "11",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/exterieur-scandi-boheme-2021-2.jpg",
    "link": "/article-exterieur-scandi-boheme-terrasse-champetre-2468.htm"
  },
  {
    "id": "12",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/scandi-sdb.jpg",
    "link": "/article-salle-de-bains-scandi-boheme-un-mariage-harmonieux-des-tons-sable-et-terracotta-2364.htm"
  },
  {
    "id": "13",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/sejour-loft-scandi-boheme-2021.jpg",
    "link": "/article-sejour-scandi-boheme-cosy-et-chaleureux-sous-les-combles-2426.htm"
  
  },
  {
    "id": "14",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/chambre-scandi-boheme-2023-2.jpg",
    "link": "/article-chambre-scandi-boheme-dortoir-a-la-campagne-2436.htm"
  },
  {
    "id": "15",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/sdb-scandi-boheme-2022.jpg",
    "link": "/article-sdb-scandi-boheme-ambiance-sauna-apaisant-2451.htm"
  },
  {
    "id": "16",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/exterieur-scandi-boheme-2021.jpg",
    "link": "/article-exterieur-scandi-boheme-syle-maison-cap-ferret-2466.htm"
  },
  {
    "id": "17",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/exterieur/exterieur-scandi-boheme-2025.jpg",
    "link": "/article-exterieur-scandi-boheme-2500.htm"
  },
  {
    "id": "18",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/chambre/chambre-scandi-boheme-2025.jpg",
    "link": "/article-chambre-scandi-boheme-2501.htm"
  },
  {
    "id": "19",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/entree/entree-scandi-boheme-2025.jpg",
    "link": "/article-entree-scandi-boheme-2502.htm"
  }

];
