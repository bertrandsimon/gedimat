const data = [
  {
    "id": "1",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/design-salon.jpg",
    "link": "/article-sejour-design-epure-la-simplicite-cache-bien-son-jeu-2352.htm"
  },
  {
    "id": "2",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/design-terrasse.jpg",
    "link": "/article-terrasse-design-epure-un-espace-minimaliste-aux-tons-neutres-2311.htm"
  },
  {
    "id": "3",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/chambre-design-epure-2022.jpg",
    "link": "/article-chambre-design-epure-suite-parentale-avec-vue-exterieure-2440.htm"
  },
  {
    "id": "4",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/exterieur-design-epure-2022-2.jpg",
    "link": "/article-exterieur-design-epure-espace-detente-ombrage-2461.htm"
  },
  {
    "id": "5",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/design-chambre.jpg",
    "link": "/article-chambre-design-epure-apaisante-pour-se-ressourcer-2345.htm"
  },
  {
    "id": "6",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/sejour-design-epure-2023.jpg",
    "link": "/article-sejour-design-epure-un-interieur-clair-et-contemporain-2419.htm"
  },
  {
    "id": "7",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/exterieur-design-epure-2023.jpg",
    "link": "/article-exterieur-design-epure-terrasse-amenagee-en-patio-2455.htm"
  },
  {
    "id": "8",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/tendances/design-sdb.jpg",
    "link": "/article-salle-de-bains-design-epure-epuree-et-audacieuse-2362.htm"
  },
  {
    "id": "9",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/sejour-design-epure-2021.jpg",
    "link": "/article-sejour-design-epure-design-authentique-avec-parement-2427.htm"
  },
  {
    "id": "10",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/exterieur-design-epure-2022.jpg",
    "link": "/article-exterieur-design-epure-terrasse-ambiance-bord-de-mer-2460.htm"
  },
  {
    "id": "11",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/cuisine/cuisine-design-epure-2025.jpg",
    "link": "/article-cuisine-design-epure-2506.htm"
  },
  {
    "id": "12",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances/galeries/pieces/entree/entree-design-epure-2025.jpg",
    "link": "/article-entree-design-epure-2507.htm"
  },
  {
    "id": "13",
    "img_url": "https://uploads.gedimat.fr/CMS/images/tendances2024/pieces/exterieur-design-epure-2022.jpg",
    "link": "/article-exterieur-design-epure-2508.htm"
  }
];
